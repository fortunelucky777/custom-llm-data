# Licensed under a 3-clause BSD style license - see LICENSE.rst

from .main import main

if __name__ == '__main__':
    main()
