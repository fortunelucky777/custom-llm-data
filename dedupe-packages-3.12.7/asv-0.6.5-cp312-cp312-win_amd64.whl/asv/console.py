from asv_runner.console import Log

log = Log()
