from black import patched_main

patched_main()
