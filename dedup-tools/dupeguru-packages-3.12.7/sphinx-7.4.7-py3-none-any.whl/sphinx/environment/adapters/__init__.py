"""Sphinx environment adapters"""
