============
gitchangelog
============

.. image:: https://img.shields.io/pypi/v/gitchangelog.svg?style=flat
   :target: https://pypi.python.org/pypi/gitchangelog/
   :alt: Latest PyPI version

.. image:: https://img.shields.io/pypi/dm/gitchangelog.svg?style=flat
   :target: https://pypi.python.org/pypi/gitchangelog/
   :alt: Number of PyPI downloads

.. image:: https://img.shields.io/travis/vaab/gitchangelog/master.svg?style=flat
   :target: https://travis-ci.org/vaab/gitchangelog/
   :alt: Travis CI build status

.. image:: https://img.shields.io/appveyor/ci/vaab/gitchangelog.svg
   :target: https://ci.appveyor.com/project/vaab/gitchangelog/branch/master
   :alt: Appveyor CI build status

.. image:: https://img.shields.io/codecov/c/github/vaab/gitchangelog.svg
   :target: https://codecov.io/gh/vaab/gitchangelog
   :alt: Test coverage


Use your commit log to make beautifull and configurable changelog file.


Feature
=======

- fully driven by a config file that can be tailored with your changelog
  policies. (see for example the `reference configuration file`_)
- filter out commits/tags based on regexp matching
- refactor commit summary, or commit body on the fly with replace regexp
- classify commit message into sections (ie: New, Fix, Changes...)
- any output format supported thanks to templating, you can even choose
  your own preferred template engine (mako, mustache, full python ...).
- support your merge or rebase workflows and complicated git histories
- support full or incremental changelog generation to match your needs.
- support easy access to `trailers key values`_ (if you use them)
- support of multi-authors for one commit through ``Co-Authored-By`` `trailers key values`_
- support standard python installation or dep-free single executable.
  (this last feature is not yet completely pain free to use on Windows)

.. _trailers key values: https://git.wiki.kernel.org/index.php/CommitMessageConventions


Requirements
============

``gitchangelog`` is compatible Python 2 and Python 3 on
Linux/BSD/MacOSX and Windows.

Please submit an issue if you encounter incompatibilities.


Installation
============


full package
------------

Gitchangelog is published on PyPI, thus:

    pip install gitchangelog

\.. is the way to go for install the full package on any platform.

If you are installing from source, please note that the development tools
are not working fully yet on Windows.

The full package provides the ``gitchangelog.py`` executable as long as:

- a `reference configuration file`_ that provides system wide defaults for
  all values.
- some example templates in ``mustache`` and ``mako`` templating
  engine's language. Ideal to bootstrap your variations.


from source
-----------

If you'd rather work from the source repository, it supports the common
idiom to install it on your system::

    python setup.py install

Note that for linux/BSD, there's a link to the executable in the root of the
source. This can be a convenient way to work on the source version.


single executable installation
------------------------------

The file ``gitchangelog.py`` is a full blown executable and can be used
without any other files. This is easier to use naturally on Linux/BSD
systems. For instance, you could type in::

    curl -sSL https://raw.githubusercontent.com/vaab/gitchangelog/master/src/gitchangelog/gitchangelog.py > /usr/local/bin/gitchangelog &&
    chmod +x /usr/local/bin/gitchangelog

It'll install ``gitchangelog`` to be accessible for all users and will
use the default python interpreter of your running session.

Please note: if you choose to install it in this standalone mode, then
you must make sure to value at least all the required configuration
keys in your config file. As a good start you should probably copy the
`reference configuration file`_ as you base configuration file.

This is due to the fact that ``gitchangelog`` can not anymore reach
the reference configuration file to get default values.


Sample
======

The default output is ReSTructured text, so it should be readable in ASCII.

Here is a small sample of the ``gitchangelog`` changelog at work.

Current ``git log`` output so you can get an idea of the log history::

  * 59f902a Valentin Lab new: dev: sections in changelog are now in the order given in ``gitchangelog.rc`` in the ``section_regexps`` option.  (0.1.2)
  * c6f72cc Valentin Lab chg: dev: commented code to toggle doctest mode.
  * a9c38f3 Valentin Lab fix: dev: doctests were failing on this.
  * 59524e6 Valentin Lab new: usr: added ``body_split_regexp`` option to attempts to format correctly body of commit.
  * 5883f07 Valentin Lab new: usr: use a list of tuple instead of a dict for ``section_regexps`` to be able to manage order between section on find match.
  * 7c1d480 Valentin Lab new: dev: new ``unreleased_version_label`` option in ``gitchangelog.rc`` to change label of not yet released code.
  * cf29c9c Valentin Lab fix: dev: bad sorting of tags (alphanumerical). Changed to commit date sort.
  * 61d8f80 Valentin Lab fix: dev: support of empty commit message.
  * eeca31b Valentin Lab new: dev: use ``gitchangelog`` section in ``git config`` world appropriately.
  * 6142b71 Valentin Lab chg: dev: cosmetic removal of trailing whitespaces
  * 3c3edd5 Valentin Lab fix: usr: ``git`` in later versions seems to fail on ``git config <key>`` with errlvl 255, that was not supported.
  * 3f9617d Valentin Lab fix: usr: removed Traceback when there were no tags at all in the current git repository.
  * e0db9ae Valentin Lab new: usr: added section classifiers (ie: New, Change, Bugs) and updated the sample rc file.  (0.1.1)
  * 0c66d59 Valentin Lab fix: dev: Fixed case where exception was thrown if two tags are on the same commit.
  * d2fae0d Valentin Lab new: usr: added a succint ``--help`` support.

And here is the ``gitchangelog`` output::

  0.1.2 (2011-05-17)
  ------------------

  New
  ~~~
  - Sections in changelog are now in the order given in ``git-
    changelog.rc`` in the ``section_regexps`` option. [Valentin Lab]
  - Added ``body_split_regexp`` option to attempts to format correctly
    body of commit. [Valentin Lab]
  - Use a list of tuple instead of a dict for ``section_regexps`` to be
    able to manage order between section on find match. [Valentin Lab]
  - New ``unreleased_version_label`` option in ``gitchangelog.rc`` to
    change label of not yet released code. [Valentin Lab]
  - Use ``gitchangelog`` section in ``git config`` world appropriately.
    [Valentin Lab]

  Changes
  ~~~~~~~
  - Commented code to toggle doctest mode. [Valentin Lab]
  - Cosmetic removal of trailing whitespaces. [Valentin Lab]

  Fix
  ~~~
  - Doctests were failing on this. [Valentin Lab]
  - Bad sorting of tags (alphanumerical). Changed to commit date sort.
    [Valentin Lab]
  - Support of empty commit message. [Valentin Lab]
  - ``git`` in later versions seems to fail on ``git config <key>`` with
    errlvl 255, that was not supported. [Valentin Lab]
  - Removed Traceback when there were no tags at all in the current git
    repository. [Valentin Lab]


  0.1.1 (2011-04-07)
  ------------------

  New
  ~~~
  - Added section classifiers (ie: New, Change, Bugs) and updated the
    sample rc file. [Valentin Lab]
  - Added a succint ``--help`` support. [Valentin Lab]

  Fix
  ~~~
  - Fixed case where exception was thrown if two tags are on the same
    commit. [Valentin Lab]

And the rendered full result is directly used to generate the HTML webpage of
the `changelog of the PyPI page`_.


Usage
=====

The `reference configuration file`_ is delivered within
``gitchangelog`` package and is used to provides defaults to
settings. If you didn't install the package and used the standalone
file, then chances are that ``gitchangelog`` can't access these
defaults values. This is not a problem as long as you provided all the
required values in your config file.

The recommended location for ``gitchangelog`` config file is the root
of the current git repository with the name ``.gitchangelog.rc``.
However you could put it elsewhere, and here are the locations checked
(first match will prevail):

- in the path given thanks to the environment variable
  ``GITCHANGELOG_CONFIG_FILENAME``
- in the path stored in git config's entry ``gitchangelog.rc-path`` (which
  could be stored in system location or per repository)
- (RECOMMENDED) in the root of the current git repository with the name
  ``.gitchangelog.rc``

Then, you'll be able to call ``gitchangelog`` in a GIT repository and it'll
print changelog on its standard output.


Configuration file format
-------------------------

The `reference configuration file`_ is quite heavily commented and is quite
simple.  You should be able to use it as required.

.. _reference configuration file: https://github.com/vaab/gitchangelog/blob/master/src/gitchangelog/gitchangelog.rc.reference

The changelog of gitchangelog is generated with himself and with the reference
configuration file. You'll see the output in the `changelog of the PyPI page`_.

.. _changelog of the PyPI page: http://pypi.python.org/pypi/gitchangelog


Output Engines
--------------

At the end of the configuration file, you'll notice a variable called
``output_engine``. By default, it's set to ``rest_py``, which is the
legacy python engine to produce the `ReSTructured Text` output format
that is shown in above samples. If this engine fits your needs, you
won't need to fiddle with this option.

To render the template, ``gitchangelog`` will generate a data structure that
will then be rendered thanks to the output engine. This should help you get
the exact output that you need.

As people might have different needs and knowledge, a templating
system using ``mustache`` is available. ``mustache`` templates are
provided to render both `ReSTructured Text` or `markdown` formats. If
you know ``mustache`` templating, then you could easily add or modify
these existing templates.

A ``mako`` templating engine is also provided. You'll find also a ``mako``
template producing the same `ReSTructured Text` output than the legacy one.
It's provided for reference and/or further tweak if you would rather use `mako`_
templates.


Mustache
~~~~~~~~

The ``mustache``  output engine uses `mustache templates`_.

The `mustache`_ templates are powered via `pystache`_ the python
implementation of the `mustache`_ specifications. So `mustache`_ output engine
will only be available if you have `pystache`_ module available in your python
environment.

There are `mustache templates`_ bundled with the default installation
of gitchangelog. These can be called by providing a simple label to the
``mustache(..)`` output_engine, for instance (in your ``.gitchangelog.rc``)::

    output_engine = mustache("markdown")

Or you could provide your own mustache template by specifying an
absolute path (or a relative one, starting from the git toplevel of
your project by default, or if set, the
``git config gitchangelog.template-path``
location) to your template file, for instance::

    output_engine = mustache(".gitchangelog.tpl")

And feel free to copy the bundled templates to use them as bases for
your own variations. In the source code, these are located in
``src/gitchangelog/templates/mustache`` directory, once installed they
are in ``templates/mustache`` directory starting from where your
``gitchangelog.py`` was installed.


.. _mustache: http://mustache.github.io
.. _pystache: https://pypi.python.org/pypi/pystache
.. _mustache templates: http://mustache.github.io/mustache.5.html


Mako
~~~~

The ``makotemplate`` output engine templates for ``gitchangelog`` are
powered via `mako`_ python templating system. So `mako`_ output engine
will only be available if you have `mako`_ module available in your
python environment.

There are `mako`_ templates bundled with the default installation
of gitchangelog. These can be called by providing a simple label to the
``makotemplate(..)`` output_engine, for instance (in your ``.gitchangelog.rc``)::

    output_engine = makotemplate("markdown")

Or you could provide your own mustache template by specifying an
absolute path (or a relative one, starting from the git toplevel of
your project by default, or if set, the
``git config gitchangelog.template-path``
location) to your template file, for instance::

    output_engine = makotemplate(".gitchangelog.tpl")

And feel free to copy the bundled templates to use them as bases for
your own variations. In the source code, these are located in
``src/gitchangelog/templates/mako`` directory, once installed they
are in ``templates/mako`` directory starting from where your
``gitchangelog.py`` was installed.

.. _mako: http://www.makotemplates.org


Changelog data tree
~~~~~~~~~~~~~~~~~~~

This is a sample of the current data structure sent to output engines::

  {'title': 'Changelog',
   'versions': [{'label': '%%version%% (unreleased)',
                 'date': None,
                 'tag': None
                 'sections': [{'label': 'Changes',
                               'commits': [{'author': 'John doe',
                                            'body': '',
                                            'subject': 'Adding some extra values.'},
                                           {'author': 'John Doe',
                                            'body': '',
                                            'subject': 'Some more changes'}]},
                              {'label': 'Other',
                               'commits': [{'author': 'Jim Foo',
                                            'body': '',
                                            'subject': 'classic modification'},
                                           {'author': 'Jane Done',
                                            'body': '',
                                            'subject': 'Adding some stuff to do.'}]}]},
                {'label': 'v0.2.5 (2013-08-06)',
                 'date': '2013-08-06',
                 'tag': 'v0.2.5'
                 'sections': [{'commits': [{'author': 'John Doe',
                                            'body': '',
                                            'subject': 'Updating Changelog installation.'}],
                               'label': 'Changes'}]}]}


Merged branches history support
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Commit attribution to a specific version could be tricky. Suppose you have
this typical merge tree (spot the tags!)::

    * new: something  (HEAD, tag: 0.2, develop)
    *   Merge tag '0.1.1' into develop
    |\
    | * fix: out-of-band hotfix  (tag: 0.1.1)
    * | chg: continued development
    |/
    * fix: something  (tag: 0.1)
    * first commit  (tag: 0.0.1, master)

Here's a minimal draft of gitchangelog to show how commit are
attributed to versions::

    0.2
      * new: something.
      * Merge tag '0.1.1' into develop.
      * chg: continued development.

    0.1.1
      * fix: out-of-band hotfix.

    0.1
      * fix: something.


.. note:: you can remove automatically all merge commit from
  gitchangelog output by using ``include_merge = False`` in the
  ``.gitchangelog.rc`` file.


Use cases
=========


No sectionning
--------------

If you want to remove sectionning but keep anything else, you should
probably use::

    section_regexps = [
        ('', None)
    ]

    subject_process = (strip | ucfirst | final_dot)

This will disable sectionning and won't remove the prefixes
used for sectionning from the commit's summary.


Incremental changelog
---------------------

Also known as partial changelog generation, this feature allows to
generate only a subpart of your changelog, and combined with
configurable publishing actions, you can insert the result inside
an existing changelog. Usually this makes sense:

- When wanting to switch to ``gitchangelog``, or change your
  conventions:

  - part of your history is not following conventions.
  - you have a previous CHANGELOG you want to blend in.

- You'd rather commit changes to your changelog file for each release:

  - For performance reason, you can then generate changelog only for
    the new commit and save the result.
  - Because you want to be able to edit it to make some minor
    edition if needed.


Generating partial changelog is as simple as ``gitchangelog
REVLIST``. Examples follows::

    ## will output only tags between 0.0.2 (excluded) and 0.0.3 (included)
    gitchangelog 0.0.2..0.0.3

    ## will output only tags since 0.0.3 (excluded)
    gitchangelog ^0.0.3 HEAD

    ## will output all tags up to 0.0.3 (included)
    gitchangelog 0.0.3


Additionally, ``gitchangelog`` can figure out automatically which
revision is the last for you (with some little help). This is done by
specifying the ``revs`` config option. This config file option will be
used as if specified on the command line.

Here is an example that fits the current changelog format::

    revs = [
        Caret(
            FileFirstRegexMatch(
    	        "CHANGELOG.rst",
    	        r"(?P<rev>[0-9]+\.[0-9]+(\.[0-9]+))\s+\([0-9]+-[0-9]{2}-[0-9]{2}\)\n--+\n")),
    ]

This will look into the file ``CHANGELOG.rst`` for the first match of
the given regex and return the match of the ``rev`` regex sub-pattern
it as a string. The ``Caret`` function will simply prefix the given
string with a ``^``. As a consequence, this code will prevent
recreating any previously generated changelog section (more information
about the `REVLIST syntax`_ from ``git rev-list`` arguments.)

.. _REVLIST syntax: https://git-scm.com/docs/git-rev-list#_description

Note that the data structure provided to the template will set the
``title`` to ``None`` if you provided no REVLIST through command-line
or the config file (or if the revlist was equivalently set to
``["HEAD", ]``).  This a good way to make your template detect it is
in "incremental mode".

By default, this will only output to standard output the new sections
of your changelog, you might want to insert it directly in your existing
changelog. This is where ``publish`` parameters will help you. By default
it is set to ``stdout``, and you might want to set it to::

    publish = FileInsertIntoFirstRegexMatch(
        "CHANGELOG.rst",
        r'/(?P<rev>[0-9]+\.[0-9]+(\.[0-9]+)?)\s+\([0-9]+-[0-9]{2}-[0-9]{2}\)\n--+\n/',
        idx=lambda m: m.start(1)
    )

The full recipe could be::

    OUTPUT_FILE = "CHANGELOG.rst"
    INSERT_POINT = r"\b(?P<rev>[0-9]+\.[0-9]+)\s+\([0-9]+-[0-9]{2}-[0-9]{2}\)\n--+\n"
    revs = [
            Caret(FileFirstRegexMatch(OUTPUT_FILE, INSERT_POINT)),
            "HEAD"
    ]

    action = FileInsertAtFirstRegexMatch(
        OUTPUT_FILE, INSERT_POINT,
        idx=lambda m: m.start(1)
    )


Alternatively, you can use this other recipe, using ``FileRegexSubst``, that has
the added advantage of being able to update the unreleased part if you had it already
generated and need a re-fresh because you added new commits or amended some commits::

    OUTPUT_FILE = "CHANGELOG.rst"
    INSERT_POINT_REGEX = r'''(?isxu)
    ^
    (
      \s*Changelog\s*(\n|\r\n|\r)        ## ``Changelog`` line
      ==+\s*(\n|\r\n|\r){2}              ## ``=========`` rest underline
    )

    (                     ## Match all between changelog and release rev
        (
          (?!
             (?<=(\n|\r))                ## look back for newline
             %(rev)s                     ## revision
             \s+
             \([0-9]+-[0-9]{2}-[0-9]{2}\)(\n|\r\n|\r)   ## date
               --+(\n|\r\n|\r)                          ## ``---`` underline
          )
          .
        )*
    )

    (?P<rev>%(rev)s)
    ''' % {'rev': r"[0-9]+\.[0-9]+(\.[0-9]+)?"}

    revs = [
        Caret(FileFirstRegexMatch(OUTPUT_FILE, INSERT_POINT_REGEX)),
        "HEAD"
    ]

    publish = FileRegexSubst(OUTPUT_FILE, INSERT_POINT_REGEX, r"\1\o\g<rev>")


As a second example, here is the same recipe for mustache markdown format::

    OUTPUT_FILE = "CHANGELOG.rst"
    INSERT_POINT_REGEX = r'''(?isxu)
    ^
    (
      \s*\#\s+Changelog\s*(\n|\r\n|\r)        ## ``Changelog`` line
    )

    (                     ## Match all between changelog and release rev
        (
          (?!
             (?<=(\n|\r))                ## look back for newline
             \#\#\s+%(rev)s                     ## revision
             \s+
             \([0-9]+-[0-9]{2}-[0-9]{2}\)(\n|\r\n|\r)   ## date
          )
          .
        )*
    )

    (?P<tail>\#\#\s+(?P<rev>%(rev)s))
    ''' % {'rev': r"[0-9]+\.[0-9]+(\.[0-9]+)?"}

    revs = [
        Caret(FileFirstRegexMatch(OUTPUT_FILE, INSERT_POINT_REGEX)),
        "HEAD"
    ]

    publish = FileRegexSubst(OUTPUT_FILE, INSERT_POINT_REGEX, r"\1\o\n\g<tail>")


Contributing
============

Any suggestion or issue is welcome. Push request are very welcome,
please check out the guidelines.


Push Request Guidelines
-----------------------

You can send any code. I'll look at it and will integrate it myself in
the code base while leaving you as the commit(s) author. This process
can take time and it'll take less time if you follow the following
guidelines:

- check your code with PEP8 or pylint. Try to stick to 80 columns wide.
- separate your commits per smallest concern
- each functionality/bugfix commit should contain the code, tests,
  and doc.
- each commit should pass the tests (to allow easy bisect)
- prior minor commit with typographic or code cosmetic changes are
  very welcome. These should be tagged in their commit summary with
  ``!minor``.
- the commit message should follow gitchangelog rules (check the git
  log to get examples)
- if the commit fixes an issue or finished the implementation of a
  feature, please mention it in the summary.

If you have some questions about guidelines which is not answered here,
please check the current ``git log``, you might find previous commit that
would show you how to deal with your issue. Otherwise, just send your PR
and ask your question. I won't bite. Promise.


License
=======

Copyright (c) 2012-2018 Valentin Lab.

Licensed under the `BSD License`_.

.. _BSD License: http://raw.github.com/vaab/gitchangelog/master/LICENSE

Changelog
=========


3.0.4 (2018-03-17)
------------------

Fix
~~~
- Conform to PEP479 as required by python 3.7 (fixes #101) [Valentin
  Lab]


3.0.3 (2017-04-23)
------------------

Fix
~~~
- API cli change not documented about implicit ``HEAD`` removed in
  revision list specifier. (fixes #81) [Valentin Lab]

  In 2.5.1, ``gitchangelog show ^3.0.0`` command would implicitly add a
  ``HEAD`` in the revlist specifiers, effectively being equivalent to
  ``0.0.3..HEAD``.

  This behavior is removed in 3.0.0+ to stick to ``git rev-list REVLIST``
  syntax.  As a consequence, ``gitchangelog ^3.0.0`` won't select any
  revision and thus will cast an error about no commits matching revlist.


3.0.2 (2017-04-21)
------------------

Fix
~~~
- [mustache/markdown] template is now compatible with incremental
  changelog generation patterns. (fixes #80) [Valentin Lab]


3.0.1 (2017-03-17)
------------------

Fix
~~~
- Support of commits with empty message. (fixes #76) [Valentin Lab]


3.0.0 (2017-03-17)
------------------

New
~~~
- Template path can now be specified in ``git config``. (fixes #73)
  [Valentin Lab]
- Added ``FileRegexSubst`` to allow updatable incremental recipe.
  [Valentin Lab]

  With the added function and recipe as an example, you can update a
  current unreleased changelog additionaly to the traditional incremental
  behavior. ``FileRegexSubst`` might prove itself to be more powerfull
  tahn ``FileInsertAtFirstRegexMatch`` if you handle fairly complex regexes.
- Configurable ``publish`` action to allow more automated changelog
  scenarios (fixes #39) [Valentin Lab]

  In particular, projects using incremental changelog generation can now
  fully automate the process by using a ``publish`` action that inserts
  new sections in an existing changelog file.
- ``unreleased_version_label`` can now be computed on the fly. [Valentin
  Lab]

  This can let you rename the first section about non yet tagged commit
  more precisely. For instance by using the commit hash or any git
  property.
- Full tested windows support added. [Valentin Lab]
- Reference config file is not anymore required. (fixes #54) [Valentin
  Lab]
- New ``revs`` config file option allowing dynamically setting target
  rev-list. (fixes #61) [Valentin Lab]

  With this option, incremental changelog become more streamlined. With
  prior behavior, you had to know which was the last version prior to
  calling ``gitchangelog``. Now, calling ``gitchangelog`` alone can generate
  the exact last missing part thanks to this new config option.
- Templates now support direct path to files (fixes #46, fixes #63).
  [Héctor Pablos, Valentin Lab]

  Note that relative paths will be searched from the git toplevel.
- Provide helpers to integrate ``Co-Authored-By`` trailer value. (fixes
  #69) [Valentin Lab]

  You can use now ``commit["authors"]`` in templates to get a list of all
  authors of a commit. See the mako template ``restructuredtext.tpl`` for
  example of usage. Mustache templates gets also their own baked in joined
  list of authors through ``commit["author_names_joined"]``.
- Provide complete access on commit API to templates (fixes #18)
  [Valentin Lab]
- Supports trailer key values support. [Valentin Lab]
- Windows compatibility. [Jean-Baptiste Lab, Laurent LAPORTE, Michele,
  Valentin Lab]

Changes
~~~~~~~
- Use tagger date when tags are annotated instead of commit date. (fixes
  #60) [Valentin Lab]
- Removed the need of the ``show`` positional argument. [Valentin Lab]
- Suppression of the obsolete ``gitchangelog init`` command. [Valentin
  Lab]

Fix
~~~
- Support closed or closing pipes on gitchangelog's stdout gracefully.
  [Valentin Lab]

  Python would output some angry comments for instance when using::

       gitchangelog | head

  Now it is much more graceful and will let the process finish earlier
  without complaining.
- Revlist would not work as expected on windows. [Valentin Lab]

  Windows does not support single quotes in command line as linux
  does. Fortunately there is no requirements on singles quotes so they
  were removed everywhere, ensuring a better windows compatibility.
- Using revlists could display unwanted commits or no commits. [Valentin
  Lab]

  This was happening when specifying revisions that didn't match
  commits tagged by tags matching the ``tag_filter_regexp``.
- Ability to specify rev-lists for partial changelogs creation was not
  working on windows. [Valentin Lab]
- Encoding issues prevented log to be outputed on specific windows
  versions. [Valentin Lab]
- Fixed encoding issue when reading UTF-8 git logs with a different
  default locale. [Valentin Lab]

  Windows platform were more likely to get hit by this bug as their
  default code page is not ``utf-8``. It was fixed by using an explicit
  encoding when reading git logs. The default value for this encoding
  can now be set in the ``gitchangelog``'s config file, per-repository.
  Although, this option should be only set in pathological configuration
  as the default behavior is to use ``git config i18n.logOutputEncoding``
  when set, or if not set, ``utf-8``, which is the default log encoding
  of git.


2.5.1 (2015-11-11)
------------------

Fix
~~~
- Reference config is used for defaults. [Tuukka Mustonen]
- Error message when called in non-git directories was not correctly
  displayed on python 3. [Valentin Lab]
- ``--debug`` argument would generate command line arguments parsing
  errors on python 2.7.  (fixes #66) [Valentin Lab]


2.5.0 (2016-10-16)
------------------

New
~~~
- Hide unexpected traceback per default and allow them to be displayed
  if wanted. [Valentin Lab]
- New lines fixes in current default ReST format (fixes #62) [Stavros
  Korokithakis]

  These were modified:

  - no new line between list element, except when there's some
    body message to display, then use only one new line at the
    beginning of the body to issues with possible lists in body.
  - one new line before section titles.
  - two new lines before versions titles.

Fix
~~~
- Output warning on stderr in some weird cases (fixes #52) [Valentin
  Lab]

  If no tag are found in the repository, or no tag matches the filter
  regex, or if all commits are ignored... this will lead to disturbing but
  legit outputs from ``gitchangelog``. So as to help diagnose what is
  going on, additional warnings are then printed when edge cases are
  encountered.
- [mustache/restructuredtext] avoid HTML-escaping content of variables
  (fixes #64) [Mark Milstein]


2.4.0 (2015-11-10)
------------------

New
~~~
- Add optional positional argument ``REVLIST`` to allow incremental
  changelog output (fixes #26) [Valentin Lab]

  See use cases documentations for more information.


2.3.0 (2015-09-25)
------------------

Fix
~~~
- Nasty hidden bug that would break python3 (fixes #27) [Valentin Lab]

  Actually this bug was revealed by python3 random hashes (thanks to
  @rschoon for the hint) and could be reproduced on python2.7 with ``-R``
  mode.

  The ``git show`` command actually will behave differently if given a tag
  reference and print random unexpected information before using the
  format string. This would prefix a lot of mess to the first field being
  asked in the format string.

  And this first field is dependent on the internal order of a dict, and
  this order is not important as such, and so nothing was done on this
  part.

  On python2.7, somehow, it would always be the same order that revealed
  to have no consequence (probably one of the rare field not used in
  current changelogs).

  Python3 or Python2.7 -R would shuffle this order and then trigger the
  error whenever this prefix would be appended to actually important
  fields that went into some further processing (as casted to int for
  the timestamp for instance).


2.2.1 (2015-06-09)
------------------

Fix
~~~
- Fix: doc: ``ìnclude_merge`` options was wrongly typed in sample config
  files (reported by @tuukkamustonen, fixed #29). [Valentin Lab]
- Updated doc to reflec that there are no support of windows for now.
  (fixes #28) [Valentin Lab]

  Actually windows will fail on ``subprocess`` call. (see #28)
- Remove commit's meta-information footer from changelog output. (fixes
  #25) [Valentin Lab]

  Some various tools (thinking of Gerrit) might leave some
  meta-information in the footer of your commit message's body that you do
  not want to be repeated in your changelog. So all values in the footer
  are removed (This concerns ``Change-Id``, ``Acked-by``, ``CC``,
  ``Signed-off-by``, ``Bug`` ... and any other value).


2.2.0 (2015-01-27)
------------------

New
~~~
- Provide support for older config file format. [Valentin Lab]
- Added 'octobercms-plugin' mako template. (fixes #16) [Valentin Lab]
- Added ``body_process`` and ``subject_process`` options. (fixes #22)
  [Valentin Lab]

  These options superseeds ``replace_regexps`` and ``body_split_regexp``
  as they provide a full control over text transformation of the subject
  or the body of the commit before they get included in the changelog.
- Added ``include_merge`` option to filter out merge commit. [Casey
  Duquette]

Changes
~~~~~~~
- Produce a more linear commit history (fixes #14) [Casey Duquette]

  Instead of retrieving the git log ordered by date, retrieve the log as
  a difference between tags to produce a more accurate view of changes
  between releases.

  For instance, imagine this git graph::

    * 6c0fd62 (HEAD, tag: sprint-6, origin/smoke, smoke, develop)
    *   5292a28 Merge back to develop
    |\
    | * 6612fce (tag: sprint-5.1, origin/master, origin/HEAD, master) super important hotfix
    * | 7d6286f more development work
    * | 8c1e3d6 continued development work
    * | fa3d4bd development work
    |/
    * ec1a19c (tag: sprint-5)

  Previously, commits ``fa3d4bd``, ``8c1e3d6``, ``7d6286f`` that
  occurred on the develop branch before the hotfix that led to tagging
  ``sprint-5.1``, were captured in the changelog under release
  ``sprint-5.1`` because of the order of the commits. But it is obvious
  that these commits were not included in a release until
  ``sprint-6``. The new method of calculating the changelog will capture
  this and reflect it properly, assigning those changes to ``sprint-6``.

Fix
~~~
- Last commit was omitted (fixes #23). [Valentin Lab]
- Bogus messages when template didn't exist. [Valentin Lab]

  Refactored out the common code and corrected the bad error message.
- Removed hypothetical memory exhaust while parsing ``git log``.
  [Valentin Lab]

  Parse stdout as it's produced by git log by chunks.


2.1.2 (2014-04-25)
------------------

Fix
~~~
- Fail with error message when config path exists but is not a file.
  (fixes #11) [Casey Duquette]

  For example, the config file could be a directory.


2.1.1 (2014-04-15)
------------------

Fix
~~~
- Removed exception if you had file which name that matched a tag's
  name. (fixes #9) [Valentin Lab]


2.1.0 (2014-03-25)
------------------

New
~~~
- Python3 compatibility. [Valentin Lab]
- Much greater performance on big repository by issuing only one shell
  command for all the commits. (fixes #7) [Valentin Lab]
- Add ``init`` argument to create a full ``.gitchangelog.rc`` in current
  git repository. [Valentin Lab]
- Remove optional first argument that could specify the target git
  repository to consider. [Valentin Lab]

  This is to remove duplicate way to do things. ``gitchangelog`` should be run
  from within a git repository.

  Any usage of ``gitchangelog MYREPO`` can be written ``(cd MYREPO;
  gitchangelog)``.
- Use a standard formatting configuration by default. [Valentin Lab]

  A default `standard` way of formatting is used if you don't provide
  any configuration file. Additionaly, any option you define in your
  configuration file will be added "on-top" of the default configuration
  values. This can reduce config file size or even remove the need of
  one if you follow the standard.

  And, thus, you can tweak the standard for your needs by providing only partial
  configuration file. See tests for examples.
- Remove user or system wide configuration file lookup. [Valentin Lab]

  This follows reflexion that you build a changelog for a repository and
  that the rules to make the changelog should definitively be explicit and
  thus belongs to the repository itself.

  Not a justification, but removing user and system wide configuration files
  also greatly simplifies testability.

Fix
~~~
- Encoding issues with non-ascii chars. [Valentin Lab]
- Avoid using pipes for windows compatibility and be more performant by
  avoiding to unroll full log to get the last commit. [Valentin Lab]
- Better support of exotic features of git config file format. (fixes
  #4) [Valentin Lab]

  git config file format allows ambiguous keys:

      [a "b.c"]
          d = foo
      [a.b "c"]
          e = foo
      [a.b.c]
          f = foo

  Are all valid. So code was simplified to use directly ``git config``.
  This simplification will deal also with cases where section could be
  attributed values:

      [a "b"]
          c = foo
      [a]
          b = foo

  By avoiding to parse the entire content of the file, and relying on
  ``git config`` implementation we ensure to remain compatible and not
  re-implement the parsing of this file format.
- Gitchangelog shouldn't fail if it fails to parse your git config.
  [Michael Hahn]


2.0.0 (2013-08-20)
------------------

New
~~~
- Added a ``mako`` output engine with standard ReSTructured text format
  for reference. [Valentin Lab]
- Added some information on path lookup scheme to find
  ``gitchangelog.rc`` configuration file. [Valentin Lab]
- Added templating system and examples with ``mustache`` template
  support for restructured text and markdown output format. [David
  Loureiro]

Changes
~~~~~~~
- Removed ``pkg`` and ``dev`` commits from default sample changelog
  output. [Valentin Lab]

Fix
~~~
- Some error message weren't written on stderr. [Valentin Lab]


1.1.0 (2012-05-03)
------------------

New
~~~
- New config file lookup scheme which adds a new possible default
  location ``.gitchangelog.rc`` in the root of the git repository.
  [Valentin Lab]
- Added a new section to get a direct visual of ``gitchangelog`` output.
  Reworded some sentences and did some other minor additions. [Valentin
  Lab]

Changes
~~~~~~~
- Removed old ``gitchangelog.rc.sample`` in favor of the new documented
  one. [Valentin Lab]

Fix
~~~
- The sample file was not coherent with the doc, and is now accepting
  'test' and 'doc' audience. [Valentin Lab]


1.0.2 (2012-05-02)
------------------

New
~~~
- Added a new sample file heavily documented. [Valentin Lab]

Fix
~~~
- ``ignore_regexps`` where bogus and would match only from the beginning
  of the line. [Valentin Lab]
- Display author date rather than commit date. [Valentin Lab]


0.1.2 (2011-06-29)
------------------

New
~~~
- Added ``body_split_regexp`` option to attempts to format correctly
  body of commit. [Valentin Lab]
- Use a list of tuple instead of a dict for ``section_regexps`` to be
  able to manage order between section on find match. [Valentin Lab]

Fix
~~~
- ``git`` in later versions seems to fail on ``git config <key>`` with
  errlvl 255, that was not supported. [Valentin Lab]
- Removed Traceback when there were no tags at all in the current git
  repository. [Valentin Lab]


0.1.1 (2011-06-29)
------------------

New
~~~
- Added section classifiers (ie: New, Change, Bugs) and updated the
  sample rc file. [Valentin Lab]
- Added a succint ``--help`` support. [Valentin Lab]



